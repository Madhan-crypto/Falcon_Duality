import os
import sys
import dupy_unreal as dupy
from peregrine.conf import global_settings
from peregrine.controllers import four_wheeled_base
from peregrine.twins import SystemTwin

if sys.platform == "linux":
	global_settings.Settings.BASE_OUTPUT_DIRECTORY = "/home/ubuntu/Output"
else:
	global_settings.Settings.BASE_OUTPUT_DIRECTORY = os.path.join(os.path.dirname(__file__), "../../Output/")

class BaseVehicle(SystemTwin):
    def begin_play(self):
        super().begin_play()
        self.sensor_manager.start()
        self.controller = four_wheeled_base.Teleoperation(self)
        self.vehicle_movement_component = self.get_property("VehicleMovementComponent")

    def tick(self, delta_time):
        super().tick(delta_time)
        self.controller.tick(delta_time)
        self.sensor_manager.capture(self.sim_time)
        if self.input.was_key_pressed('L'):
            self.ToggleHeadlights()        

    def end_play(self):
        super().end_play()
        self.sensor_manager.stop()
    
