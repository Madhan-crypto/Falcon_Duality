from peregrine.twins import ScenarioScript
import dupy_unreal
from peregrine.usd import usd_property

dupy_unreal.set_fixed_frame_rate(True, 60)
class SedonaRZR(ScenarioScript):
    burst_cutoff = usd_property.UsdProperty("DataBurstTimeSeconds", float, required=False, default=-1)
    def begin_play(self):
        super().begin_play()
        self.umg = self.get_world().get_actors_by_tag("DuScope:/Simulation/World/BP_ActorGenericWidgets_C_0")[0]
        self.first_tick_flag = True

    def tick(self, delta_time):
        super().tick(delta_time)
        if self.first_tick_flag:
            self.set_alternative_sensor_positions()
            self.first_tick_flag = False
        try:
            if self.umg.sensor_widget.data_collect_cutoff == -1:
                self.umg.sensor_widget.data_collect_cutoff = self.burst_cutoff
        except:
            pass

    def end_play(self):
        super().end_play()

    def set_alternative_sensor_positions(self):
        transform_1 = {
                # position in cm
                "Translation": {"X": 0, "Y": 0, "Z": 200 },
                # rotation as quaternion
                "Rotation": {"X": 0, "Y": 0, "Z": 0, "W":0 },
                # scale
                "Scale3D": {"X": 1, "Y": 1, "Z": 1 }
            }
        transform_2 = {
                # position in cm
                "Translation": {"X": 200, "Y": 0, "Z": 200 },
                # rotation as quaternion
                "Rotation": {"X": 0, "Y": 0, "Z": 0, "W":0 },
                # scale
                "Scale3D": {"X": 1, "Y": 1, "Z": 1 }
            }  
        transform_3 = {
                # position in cm
                "Translation": {"X": -10, "Y": 0, "Z": 20 },
                # rotation as quaternion
                "Rotation": {"X": 0, "Y": 0, "Z": 0, "W":0 },
                # scale
                "Scale3D": {"X": 1, "Y": 1, "Z": 1 }
            }  
        transform_4 = {
                # position in cm
                "Translation": {"X": -300, "Y": 0, "Z": 200 },
                # rotation as quaternion
                "Rotation": {"X": 0, "Y": 0, "Z": 1, "W":0 },
                # scale
                "Scale3D": {"X": 1, "Y": 1, "Z": 1 }
            } 
        self.umg.sensor_positions = [transform_1,transform_2,transform_3,transform_4]
